import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from getting_mi_and_mp_rk4 import *


mi3, mp3, list_t, list_mi, list_mp = rk4_systems(
    func_MI, func_MP, 0, 0, 0, 120, 1300)


plt.xlabel("time(h)")
plt.ylabel("mass(g)")

# plot only compartimento plasmático
# plt.plot(list_t, list_mp, color="orange")
# plt.legend(["Compartimento plasmático"])
# plt.plot(list_t, list_mi, color="orange")
# plt.legend(["Compartimento central"])
# plt.plot(list_t, list_mi,list_mp, color="orange")
# plt.legend(["Compartimento central", "Compartimento plasmático"])
# plt.show()
